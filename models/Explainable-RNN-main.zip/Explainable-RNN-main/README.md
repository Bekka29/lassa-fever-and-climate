# Explainable-RNN
Research on explainability methods for RNN archetectures 

To reproduce results:
1) Run the Scrape Notebook in data to generate starting data
2) Train the models to generate the model weights. Theres are found in their respective folders:
  A)RNN
  B)LSTM
  C)GRU
3) Run the analysis.py to generate the results for each archetecture. Theres are found in their respective folders:
  A)RNN
  B)LSTM
  C)GRU
